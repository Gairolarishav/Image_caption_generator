from django.apps import AppConfig


class CaptionGeneratorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Caption_Generator'
